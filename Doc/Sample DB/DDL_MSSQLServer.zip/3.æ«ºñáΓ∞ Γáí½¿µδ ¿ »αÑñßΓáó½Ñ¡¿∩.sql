/*
 * ER/Studio Data Architect 10.0 SQL Code Generation
 * Project :      Benine.DM1
 *
 * Date Created : Sunday, April 16, 2017 23:40:21
 * Target DBMS : Microsoft SQL Server 2014
 */



CREATE TABLE Cadastre.CadastraleDivisions(
    Numero        AS               (isnull(Cadastre.CadastrDevisionHierarchyid2Name(Hierarchie),'')) PERSISTED NOT NULL,
    Nom           nvarchar(100)    NULL,
    Hierarchie    hierarchyid      NOT NULL,
    Id            AS               cast(Replace(Replace(Hierarchie.ToString(), Hierarchie.GetAncestor(1).ToString(),''),'/','') as tinyint) PERSISTED NOT NULL,
    Mere          AS               Hierarchie.GetAncestor(1) PERSISTED,
    Niveau        AS               Hierarchie.GetLevel() PERSISTED,
    Shape         geometry         NOT NULL,
    PRIMARY KEY CLUSTERED (Numero),
    UNIQUE (Hierarchie)
)
go

create Spatial index SpInd_CadastraleDivisions
	on Cadastre.CadastraleDivisions (Shape)
	with (Bounding_Box = (XMIN = 250000, XMAX = 595000, YMIN = 690000, YMAX = 1370000));
Go


CREATE TABLE Cadastre.JuridiqueObjetTypes(
    Nom    nvarchar(50)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom)
)
go




CREATE TABLE Cadastre.JuridiqueObjets(
    GUID                     uniqueidentifier    DEFAULT NewSequentialId() NOT NULL,
    JuridiqueObjetTypeNom    nvarchar(50)        NOT NULL,
    CadSecteurNumero         varchar(8)          NOT NULL,
    Shape                    geometry            NULL,
    Superficie               AS                  Round(Shape.STArea(),0) PERSISTED,
    PRIMARY KEY CLUSTERED (GUID),
    UNIQUE (JuridiqueObjetTypeNom, CadSecteurNumero, GUID), 
    FOREIGN KEY (JuridiqueObjetTypeNom)
    REFERENCES Cadastre.JuridiqueObjetTypes(Nom) ON UPDATE CASCADE,
    FOREIGN KEY (CadSecteurNumero)
    REFERENCES Cadastre.CadastraleDivisions(Numero) ON UPDATE CASCADE
)
go
create Spatial index SpInd_JuridiqueObjets
	on Cadastre.JuridiqueObjets (Shape)
	with (Bounding_Box = (XMIN = 250000, XMAX = 595000, YMIN = 690000, YMAX = 1370000));
go


CREATE TABLE Cadastre.Parcelles(
    GUID                           uniqueidentifier    DEFAULT NewID() NOT NULL,
    ParcelleSurCadSecteurNumero    AS                  Cadastre.ExtractParcelNumberInCadSector(NUP),
    NUP                            varchar(25)         NOT NULL,
    SiArpentageFrontiere           bit                 DEFAULT 0 NOT NULL,
    CHECK (Services.RegExIsMatch('^(?<Parcel>(?<Sector>(?<Zone>(?<Department>[0-9]{1,2})-[0-9]{1,2})-[0-9]{1,2})-[0-9]+)$', NUP, null) = 1),
    PRIMARY KEY CLUSTERED (GUID),
    UNIQUE (NUP), 
    FOREIGN KEY (GUID)
    REFERENCES Cadastre.JuridiqueObjets(GUID) ON DELETE CASCADE
)
go




CREATE TABLE Cadastre.CertificationDocumentTypes(
    Nom    nvarchar(50)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom)
)
go




CREATE TABLE Cadastre.CertificationDocuments(
    Id                              int                 IDENTITY(1,1),
    ParcelleGUID                    uniqueidentifier    DEFAULT NewID() NOT NULL,
    CertificationDocumentTypeNom    nvarchar(50)        NOT NULL,
    Date                            date                NOT NULL,
    Num                             varchar(10)         NULL,
    PRIMARY KEY NONCLUSTERED (Id),
    UNIQUE CLUSTERED (ParcelleGUID, Date), 
    FOREIGN KEY (ParcelleGUID)
    REFERENCES Cadastre.Parcelles(GUID) ON DELETE CASCADE,
    FOREIGN KEY (CertificationDocumentTypeNom)
    REFERENCES Cadastre.CertificationDocumentTypes(Nom)
)
go




CREATE TABLE Cadastre.Immeubles(
    GUID                         uniqueidentifier    DEFAULT NewID() NOT NULL,
    NUP                          varchar(30)         NOT NULL,
    ParcelleNUP                  AS                  Cadastre.ExtractParcelCadastralNumber(NUP) PERSISTED NOT NULL,
    ImmeubleSurParcelleNumero    AS                  Cadastre.ExtractBuildingNumberInParcel(NUP),
    Nom                          nvarchar(100)       NULL,
    PiecesNombre                 smallint            NULL,
    EtagesNombre                 tinyint             NULL,
    CHECK (Services.RegExIsMatch('^(?<Building>(?<Parcel>(?<Sector>(?<Zone>(?<Department>[0-9]{1,2})-[0-9]{1,2})-[0-9]{1,2})-[0-9]+)(-[a-z]+))$', NUP, null) = 1),
    PRIMARY KEY CLUSTERED (GUID),
    UNIQUE (NUP), 
    FOREIGN KEY (GUID)
    REFERENCES Cadastre.JuridiqueObjets(GUID) ON DELETE CASCADE
)
go




CREATE TABLE Cadastre.Impots(
    Id              int                 IDENTITY(1,1),
    ParcelleGUID    uniqueidentifier    DEFAULT NewID() NOT NULL,
    Date            date                DEFAULT cast (GetDate() as Date) NOT NULL,
    Somme           decimal(19, 2)      NOT NULL,
    Document        nvarchar(50)        NOT NULL,
    PRIMARY KEY NONCLUSTERED (Id),
    UNIQUE CLUSTERED (ParcelleGUID, Date), 
    FOREIGN KEY (ParcelleGUID)
    REFERENCES Cadastre.Parcelles(GUID) ON DELETE CASCADE
)
go




CREATE TABLE Cadastre.SinistreeTypes(
    Nom    nvarchar(50)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom)
)
go





CREATE TABLE Cadastre.SinistreeRegions(
    Id                  int             IDENTITY(1,1),
    SinistreeTypeNom    nvarchar(50)    NOT NULL,
    Influence           nvarchar(25)    NULL,
    InfluenceCoefficient    float           NULL,
    Shape               geometry        NOT NULL,
    PRIMARY KEY CLUSTERED (Id), 
    FOREIGN KEY (SinistreeTypeNom)
    REFERENCES Cadastre.SinistreeTypes(Nom) ON UPDATE CASCADE
)
go
create Spatial index SpInd_SinistreeRegions
	on Cadastre.SinistreeRegions (Shape)
	with (Bounding_Box = (XMIN = 250000, XMAX = 595000, YMIN = 690000, YMAX = 1370000));
go



CREATE TABLE Cadastre.UtilisationTypes(
    Nom    nvarchar(150)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom)
)
go




CREATE TABLE Cadastre.Utilisations(
    Id                    int                 IDENTITY(1,1),
    UtilisationTypeNom    nvarchar(150)       NOT NULL,
    JuridiqueObjetGUID    uniqueidentifier    DEFAULT NewID() NOT NULL,
    Date                  date                DEFAULT cast (GetDate() as Date) NOT NULL,
    Document              nvarchar(50)        NOT NULL,
    PRIMARY KEY NONCLUSTERED (Id),
    UNIQUE CLUSTERED (JuridiqueObjetGUID, Date), 
    FOREIGN KEY (JuridiqueObjetGUID)
    REFERENCES Cadastre.JuridiqueObjets(GUID) ON DELETE CASCADE,
    FOREIGN KEY (UtilisationTypeNom)
    REFERENCES Cadastre.UtilisationTypes(Nom) ON UPDATE CASCADE
)
go




CREATE TABLE Juridique.JuridiqueTypes(
    Nom    nvarchar(50)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom)
)
go




CREATE TABLE Juridique.TransactionTypes(
    Nom                 nvarchar(50)    NOT NULL,
    JuridiqueTypeNom    nvarchar(50)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom), 
    FOREIGN KEY (JuridiqueTypeNom)
    REFERENCES Juridique.JuridiqueTypes(Nom) ON UPDATE CASCADE
)
go




CREATE TABLE Juridique.TransactionDocumentTypes(
    Nom    nvarchar(50)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom)
)
go




CREATE TABLE Juridique.TransactionDocuments(
    Id                            int             IDENTITY(1,1),
    TransactionDocumentTypeNom    nvarchar(50)    NOT NULL,
    Date                          date            NULL,
    Num                           varchar(10)     NULL,
    PRIMARY KEY CLUSTERED (Id), 
    FOREIGN KEY (TransactionDocumentTypeNom)
    REFERENCES Juridique.TransactionDocumentTypes(Nom) ON UPDATE CASCADE
)
go




CREATE TABLE Juridique.Transactions(
    GUID                     uniqueidentifier    DEFAULT NewSequentialId() NOT NULL,
    MereTransactionGUID      uniqueidentifier    NULL,
    TransactionTypeNom       nvarchar(50)        NOT NULL,
    TransactionDocumentId    int                 NOT NULL,
    DebutDate                date                DEFAULT cast (GetDate() as Date) NOT NULL,
    FinDate                  date                NULL,
    Observations             nvarchar(150)       NULL,
    CHECK (MereTransactionGUID <> GUID),
    PRIMARY KEY CLUSTERED (GUID), 
    FOREIGN KEY (MereTransactionGUID)
    REFERENCES Juridique.Transactions(GUID),
    FOREIGN KEY (TransactionTypeNom)
    REFERENCES Juridique.TransactionTypes(Nom) ON UPDATE CASCADE,
    FOREIGN KEY (TransactionDocumentId)
    REFERENCES Juridique.TransactionDocuments(Id) ON DELETE CASCADE
)
go




CREATE TABLE Sujet.SujetTypes(
    Nom    nvarchar(50)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom)
)
go




CREATE TABLE Sujet.Etats(
    Nom    nvarchar(100)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom)
)
go




CREATE TABLE Sujet.Sujets(
    GUID            uniqueidentifier    DEFAULT NewSequentialId() NOT NULL,
    SujetTypeNom    nvarchar(50)        NOT NULL,
    Nationalite     nvarchar(100)       DEFAULT N'Bénin' NOT NULL,
    Telephone       varchar(30)         NULL,
    Adresse         nvarchar(200)       NULL,
    BP              nvarchar(200)       NULL,
    Email           nvarchar(50)        NULL,
    PRIMARY KEY CLUSTERED (GUID), 
    FOREIGN KEY (SujetTypeNom)
    REFERENCES Sujet.SujetTypes(Nom) ON UPDATE CASCADE,
    FOREIGN KEY (Nationalite)
    REFERENCES Sujet.Etats(Nom) ON UPDATE CASCADE
)
go




CREATE TABLE Juridique.ProprietaireAncien(
    Id                 int                 IDENTITY(1,1),
    TransactionGUID    uniqueidentifier    NOT NULL,
    SujetGUID          uniqueidentifier    NOT NULL,
    PRIMARY KEY NONCLUSTERED (Id),
    UNIQUE CLUSTERED (TransactionGUID, SujetGUID), 
    FOREIGN KEY (TransactionGUID)
    REFERENCES Juridique.Transactions(GUID) ON DELETE CASCADE,
    FOREIGN KEY (SujetGUID)
    REFERENCES Sujet.Sujets(GUID)
)
go




CREATE TABLE Juridique.ProprietairePresume(
    Id                 int                 IDENTITY(1,1),
    TransactionGUID    uniqueidentifier    NOT NULL,
    SujetGUID          uniqueidentifier    NOT NULL,
    PRIMARY KEY NONCLUSTERED (Id),
    UNIQUE CLUSTERED (TransactionGUID, SujetGUID), 
    FOREIGN KEY (TransactionGUID)
    REFERENCES Juridique.Transactions(GUID) ON DELETE CASCADE,
    FOREIGN KEY (SujetGUID)
    REFERENCES Sujet.Sujets(GUID)
)
go




CREATE TABLE Juridique.TransactionObjets(
    Id                    int                 IDENTITY(1,1),
    JuridiqueObjetGUID    uniqueidentifier    DEFAULT NewID() NOT NULL,
    TransactionGUID       uniqueidentifier    NOT NULL,
    PRIMARY KEY NONCLUSTERED (Id),
    UNIQUE CLUSTERED (JuridiqueObjetGUID, TransactionGUID), 
    FOREIGN KEY (TransactionGUID)
    REFERENCES Juridique.Transactions(GUID) ON DELETE CASCADE,
    FOREIGN KEY (JuridiqueObjetGUID)
    REFERENCES Cadastre.JuridiqueObjets(GUID)
)
go




CREATE TABLE Sujet.Corporations(
    GUID    uniqueidentifier    NOT NULL,
    Nom     nvarchar(150)       NOT NULL,
    PRIMARY KEY CLUSTERED (GUID), 
    FOREIGN KEY (GUID)
    REFERENCES Sujet.Sujets(GUID) ON DELETE CASCADE
)
go




CREATE TABLE Sujet.Personnes(
    GUID             uniqueidentifier    NOT NULL,
    Nom              nvarchar(50)        NOT NULL,
    Prenoms          nvarchar(150)       NOT NULL,
    Sexe             bit                 NULL,
    NaissanceLieu    nvarchar(50)        NULL,
    NaissanceDate    date                NULL,
    Profession       nvarchar(50)        NULL,
    NomEtPrenome     as Nom + ' ' + Prenoms PERSISTED,
    PRIMARY KEY CLUSTERED (GUID), 
    FOREIGN KEY (GUID)
    REFERENCES Sujet.Sujets(GUID) ON DELETE CASCADE
)
go




CREATE TABLE Sujet.SujetDocumentTypes(
    Nom    nvarchar(50)    NOT NULL,
    PRIMARY KEY CLUSTERED (Nom)
)
go




CREATE TABLE Sujet.SujetDocument(
    Id                      int                 IDENTITY(1,1),
    SujetGUID               uniqueidentifier    NOT NULL,
    SujetDocumentTypeNom    nvarchar(50)        NOT NULL,
    Date                    date                NULL,
    Num                     varchar(10)         NULL,
    PRIMARY KEY NONCLUSTERED (Id), 
    FOREIGN KEY (SujetGUID)
    REFERENCES Sujet.Sujets(GUID) ON DELETE CASCADE,
    FOREIGN KEY (SujetDocumentTypeNom)
    REFERENCES Sujet.SujetDocumentTypes(Nom) ON UPDATE CASCADE
)
go




CREATE VIEW Cadastre.CadastraleDepartements_v AS
SELECT Ca.Numero, Ca.Id, Ca.Nom, Ca.Mere, Ca.Shape
FROM Cadastre.CadastraleDivisions Ca
WHERE Niveau = 1
WITH CHECK OPTION
go


CREATE VIEW Cadastre.CadastraleSecteurs_v AS
SELECT Ca.Numero, Ca.Id, Ca.Nom, Ca.Mere, Ca.Shape
FROM Cadastre.CadastraleDivisions Ca
WHERE Niveau = 3
WITH CHECK OPTION
go


CREATE VIEW Cadastre.CadastraleZones_v AS
SELECT Ca.Numero, Ca.Id, Ca.Nom, Ca.Mere, Ca.Shape
FROM Cadastre.CadastraleDivisions Ca
WHERE Niveau = 2
WITH CHECK OPTION
go


CREATE VIEW Cadastre.Immeubles_Parcelles_v AS
	with ParcelImm
	as
	(
		select	Pa.NUP as ParcelNUP, I.NUP as ImmeubleNUP
	
		from		(select Pa.NUP, jo.Shape
		      		from Cadastre.Parcelles as Pa join Cadastre.JuridiqueObjets as jo on jo.GUID = Pa.GUID) as Pa 
		left join	(select I.NUP, jo.Shape
		         	 from Cadastre.Immeubles as I join Cadastre.JuridiqueObjets as jo on jo.GUID = I.GUID) as I 
			on Pa.Shape.STIntersects(I.Shape) = 1
	)
	select	ParcelNUP, count(ImmeubleNUP) as ImmeublesCount
	from ParcelImm
	group by ParcelNUP
go


CREATE VIEW Cadastre.Immeubles_v AS
SELECT Im.NUP, Im.Nom, Im.PiecesNombre, Im.EtagesNombre, Ju.Shape, Ju.Superficie
FROM Cadastre.JuridiqueObjets Ju, Cadastre.Immeubles Im
WHERE Im.GUID = Ju.GUID  and 
JuridiqueObjetTypeNom = N'Immeuble'
WITH CHECK OPTION
go


CREATE VIEW Cadastre.Parcelles_v AS
SELECT Pa.NUP, Pa.SiArpentageFrontiere, Ju.Shape, Ju.Superficie
FROM Cadastre.JuridiqueObjets Ju, Cadastre.Parcelles Pa
WHERE Pa.GUID = Ju.GUID and 
JuridiqueObjetTypeNom = N'Parcelle'
WITH CHECK OPTION
go


CREATE VIEW Cadastre.Sinestree_Parcelles_v AS
SELECT Pa.NUP, Si.SinistreeTypeNom, Si.Influence, Si.InfluenceCoefficient, Sum(Pa.Shape.STIntersection(Si.Shape).STArea()) as Area
FROM Cadastre.SinistreeRegions Si join (select Pa.NUP, jo.Shape 
										from Cadastre.Parcelles Pa join Cadastre.JuridiqueObjets as jo on jo.GUID = Pa.GUID) as Pa on Si.Shape.STIntersects(Pa.Shape) = 1
group by Pa.NUP, Si.SinistreeTypeNom, Si.Influence, Si.InfluenceCoefficient
go


CREATE VIEW Juridique.JuridiqueSituations_v AS
SELECT Pa.NUP, TranT.JuridiqueTypeNom, Su.GUID ProprietarePresume, Sp.NomEtPrenome as Nom, Tr.Observations
FROM Juridique.TransactionTypes TranT, Cadastre.JuridiqueObjets Ju, Sujet.Sujets Su, Juridique.ProprietairePresume Pr, Juridique.Transactions Tr, Cadastre.Parcelles Pa, Juridique.TransactionObjets Tra, Sujet.Personnes SP
WHERE Pr.SujetGUID = Su.GUID AND Tr.TransactionTypeNom = TranT.Nom AND Pr.TransactionGUID = Tr.GUID AND Pa.GUID = Ju.GUID AND Tra.JuridiqueObjetGUID = Ju.GUID AND Tra.TransactionGUID = Tr.GUID and SP.GUID = Su.GUID
and Tr.FinDate is null
union all
SELECT Pa.NUP, TranT.JuridiqueTypeNom, Su.GUID ProprietarePresume, SC.Nom as Nom, Tr.Observations
FROM Juridique.TransactionTypes TranT, Cadastre.JuridiqueObjets Ju, Sujet.Sujets Su, Juridique.ProprietairePresume Pr, Juridique.Transactions Tr, Cadastre.Parcelles Pa, Juridique.TransactionObjets Tra, Sujet.Corporations SC
WHERE Pr.SujetGUID = Su.GUID AND Tr.TransactionTypeNom = TranT.Nom AND Pr.TransactionGUID = Tr.GUID AND Pa.GUID = Ju.GUID AND Tra.JuridiqueObjetGUID = Ju.GUID AND Tra.TransactionGUID = Tr.GUID and SC.GUID = Su.GUID
and Tr.FinDate is null

go


CREATE CLUSTERED INDEX CInd_SujetDocument ON Sujet.SujetDocument(SujetGUID)
go

